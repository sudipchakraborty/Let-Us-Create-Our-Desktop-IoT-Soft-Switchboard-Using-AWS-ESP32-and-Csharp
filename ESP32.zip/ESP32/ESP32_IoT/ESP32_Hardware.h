#include "stdint.h"
#include <Arduino.h>

// https://raw.githubusercontent.com/espressif/arduino-esp32/gh-pages/package_esp32_index.json

const int builtInLedPin = 2;
////////////////////////////
#define D23     23
#define D22     22
#define D1      1 
#define D3      3 
#define D21     21
#define D19     19
#define D18     18
#define D5      5
#define D17     17
#define D16     16
#define D2      2
#define D4      4
#define D15     15
///////////////////
#define D13   13
#define D12   12
#define D14   14
#define D27   27

#define D26   26
#define D25   25
#define D33   33
#define D32   32

//// < Only Input>/////
#define D35   35
#define D34   34
#define D39   39
#define D36   36
////////////////////////////
#define Relay_OFF   1

long delay_val=0;

uint16_t Process_Request(const char * req_type, const char * param, const char *pin, const char * val);
void Handle_Write_Request(const char * param,const char * pin, const char * val);
uint16_t Handle_Read_Request(const char * param,const char * pin);
void Device_Init(void);
void Set_Fan_Speed(unsigned char speed);
void Blink_status(void);
int getPinNumber(const char *pinName);
//________________________________________________________________________________________________________________________________________________________________________________________________
uint16_t Process_Request(const char * req_type, const char * param, const char *pin, const char * val)
{
  uint16_t ret_val;
   if((strcmp(req_type, "set") == 0) || (strcmp(req_type, "write") == 0))
   {
      Serial.println("Process_Request:Write request found");
      Handle_Write_Request(param,pin, val);
      return -1;
   }
   else if((strcmp(req_type, "get") == 0) || (strcmp(req_type, "read") == 0))
   {
       Serial.println("Process_Request:Read request found");
       ret_val= Handle_Read_Request(param, pin);
       return ret_val;
   }
   else
   {
       Serial.println("Process_Request: Invalid request found");
   }
}
//________________________________________________________________________________________________________________________________________________________________________________________________
void Handle_Write_Request(const char * param,const char * pin, const char * val)
{
    if(strcmp(param, "power_state") == 0) 
    {
        int k= getPinNumber(pin);
        if(k ==-1)
        {
            Serial.println("Error!!!! Invalid pin Number");
            return;
        }       
        if(strcmp(val, "1") == 0) 
        {
              digitalWrite(k,1);
              Serial.print("Writting to pin:");
              Serial.print(k);
              Serial.print(", value:");
              Serial.println("1");
        }
        else
        {
              digitalWrite(k,0);
              Serial.print("Writting to pin:");
              Serial.print(k);
              Serial.print(", value:");
              Serial.println("0");
        } 
    }
    /////////////////////////////////////////////////////
    if(strcmp(param, "speed") == 0) 
    {
        if(strcmp(pin, "D13") == 0) 
        {
          unsigned int speed = atoi(val);
          Set_Fan_Speed(speed);
          Serial.print("Update Fan Speed:");
          Serial.println(speed);
        }
    }
    /////////////////////////////////////////////////////
}
//_________________________________________________________________________________________________________________________________________________________________________________________ 
 uint16_t Handle_Read_Request(const char * param,const char * pin)
{
    int k;
    if(strcmp(param, "status") == 0) 
    {
        k= getPinNumber(pin);
        if(k ==-1)
        {
            Serial.println("Error!!!! Invalid pin Number");
            return -1;
        }
        else
        {
           return digitalRead(k);
        }     
    }
    else
    {
       return analogRead(k);
    }
}
//_________________________________________________________________________________________________________________________________________________________________________________________ 
void Device_Init(void)
{
  Serial.begin(115200); 
  //////////////////////////////////
  pinMode(builtInLedPin, OUTPUT);

  pinMode (D23, OUTPUT);
  pinMode (D22, OUTPUT);
  // pinMode (D1, OUTPUT); Not working as Output , it is TXD0, better not to use as DIO
 // pinMode (D3, OUTPUT); working as Digital Output, keeping not use due to it is RXD0
  pinMode (D21, OUTPUT);
 // pinMode (D19, OUTPUT);  // Not working as Output
  //pinMode (D18, OUTPUT); // Not working as Output
  //pinMode (D5, OUTPUT);  // Not working as Output
  pinMode (D17, OUTPUT);
  pinMode (D16, OUTPUT);
  //////////////////////
  pinMode (D4, OUTPUT);
  //pinMode (D2, OUTPUT);   // try to avoid, program upload error, after program IO working..
  //pinMode (D15, OUTPUT);  // try to avoid, program upload error, after program IO working..
  ////////////////////////
  pinMode (D13, OUTPUT);
  pinMode (D12, OUTPUT);
 // pinMode (D14, OUTPUT); // Not working as Output
  //pinMode (D27, OUTPUT); // Not working as Output
  pinMode (D26, OUTPUT);
  pinMode (D25, OUTPUT);
  pinMode (D33, OUTPUT);
  pinMode (D32, OUTPUT);
  //// < Only Input>/////
  pinMode (D35, INPUT);
  pinMode (D34, INPUT);
  pinMode (D39, INPUT);
  pinMode (D36, INPUT);
  ///////////////////////
  digitalWrite (D23, Relay_OFF); 
  digitalWrite (D22, Relay_OFF);
  digitalWrite (D21, Relay_OFF);
  digitalWrite (D17, Relay_OFF);
  digitalWrite (D16, Relay_OFF);
  digitalWrite (D4,  Relay_OFF);
  digitalWrite (D13, Relay_OFF);
}
//________________________________________________________________________________________________________________________________________________________________________________________________
void Set_Fan_Speed(unsigned char speed)
{
    digitalWrite (D26,  HIGH); // D0
    digitalWrite (D25,  HIGH); // D1
    digitalWrite (D33,  HIGH); // D2
    digitalWrite (D32,  HIGH); // D3
    
    switch (speed) 
    {
      case 0:
      break;
      /////////////////
      case 5:
        digitalWrite (D26,  LOW); // D0
      break;
      /////////////////
      case 10:
        digitalWrite (D25,  LOW); // D1
      break;
      /////////////////
      case 15:
        digitalWrite (D26,  LOW); // D0
        digitalWrite (D25,  LOW); // D1
      break;
      /////////////////
      case 20:
        digitalWrite (D33,  LOW); // D2
      break;
      /////////////////
      case 25:
        digitalWrite (D26,  LOW); // D0
        digitalWrite (D33,  LOW); // D2
      break;
      /////////////////
      case 30:
        digitalWrite (D25,  LOW); // D1
        digitalWrite (D33,  LOW); // D2
      break;
      /////////////////
      case 40:
        digitalWrite (D26,  LOW); // D0
        digitalWrite (D25,  LOW); // D1
        digitalWrite (D33,  LOW); // D2
      break;
      /////////////////
      case 50:
        digitalWrite (D32,  LOW); // D3
      break;
      /////////////////
      case 60:
        digitalWrite (D26,  LOW); // D0
        digitalWrite (D32,  LOW); // D3
      break;
      /////////////////
      case 65:
        digitalWrite (D25,  LOW); // D1
        digitalWrite (D32,  LOW); // D3
      break;
      /////////////////
      case 70:
        digitalWrite (D26,  LOW); // D0
        digitalWrite (D25,  LOW); // D1
        digitalWrite (D32,  LOW); // D3
      break;
      /////////////////
      case 75:
        digitalWrite (D33,  LOW); // D2
        digitalWrite (D32,  LOW); // D3
      break;
      /////////////////
      case 80:
        digitalWrite (D26,  LOW); // D0
        digitalWrite (D33,  LOW); // D2
        digitalWrite (D32,  LOW); // D3
      break;
      /////////////////
      case 85:
        digitalWrite (D25,  LOW); // D1
        digitalWrite (D33,  LOW); // D2
        digitalWrite (D32,  LOW); // D3
      break;
      /////////////////
      case 100:
        digitalWrite (D26,  LOW); // D0
        digitalWrite (D25,  LOW); // D1
        digitalWrite (D33,  LOW); // D2
        digitalWrite (D32,  LOW); // D3
      break;
      /////////////////
      default:
        digitalWrite (D26,  LOW); // D0
        digitalWrite (D25,  LOW); // D1
        digitalWrite (D33,  LOW); // D2
        digitalWrite (D32,  LOW); // D3   
      break;
      ////////////////
    }
}
//_________________________________________________________________________________________________________________________________________________________________________________________ 
void Blink_status(void)
{
  delay_val++;

  if(delay_val>250)
  {
    delay_val=0;
    digitalWrite(builtInLedPin, !digitalRead(builtInLedPin));
  }
}
//________________________________________________________________________________________________________________________________________________________________________________________________
int getPinNumber(const char *pinName) 
{
    if(strcmp(pinName, "D23") == 0)    return 23;
    if(strcmp(pinName, "D22") == 0)    return 22;
    if(strcmp(pinName, "D1") == 0)     return 1; 
    if(strcmp(pinName, "D3") == 0)     return 3; 
    if(strcmp(pinName, "D21") == 0)    return 21;
    if(strcmp(pinName, "D19") == 0)    return 19;
    if(strcmp(pinName, "D18") == 0)    return 18;
    if(strcmp(pinName, "D5") == 0)     return 5;
    if(strcmp(pinName, "D17") == 0)    return 17;
    if(strcmp(pinName, "D16") == 0)    return 16;
    if(strcmp(pinName, "D4") == 0)     return 4;
    if(strcmp(pinName, "D15") == 0)    return 15;
    ///////////////////
    if(strcmp(pinName, "D13") == 0)    return 13;
    if(strcmp(pinName, "D12") == 0)    return 12;
    if(strcmp(pinName, "D14") == 0)    return 14;
    if(strcmp(pinName, "D27") == 0)    return 27;

    if(strcmp(pinName, "D26") == 0)    return 26;
    if(strcmp(pinName, "D25") == 0)    return 25;
    if(strcmp(pinName, "D33") == 0)    return 33;
    if(strcmp(pinName, "D32") == 0)    return 32;

    // Return -1 if the pin name is not found
    return -1;
}
//________________________________________________________________________________________________________________________________________________________________________________________________











//________________________________________________________________________________________________________________________________________________________________________________________________














