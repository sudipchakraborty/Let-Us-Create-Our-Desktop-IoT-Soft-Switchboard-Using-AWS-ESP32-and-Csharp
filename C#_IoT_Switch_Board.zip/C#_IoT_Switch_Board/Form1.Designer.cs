﻿namespace IoT_Switch_Board
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pb_tube_light = new System.Windows.Forms.PictureBox();
            this.nUD_fan_speed = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.pb_light = new System.Windows.Forms.PictureBox();
            this.pb_night_lamp = new System.Windows.Forms.PictureBox();
            this.pb_tv = new System.Windows.Forms.PictureBox();
            this.pb_ac = new System.Windows.Forms.PictureBox();
            this.pb_plug = new System.Windows.Forms.PictureBox();
            this.pb_fan = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pb_tube_light)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nUD_fan_speed)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_light)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_night_lamp)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_tv)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_ac)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_plug)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_fan)).BeginInit();
            this.SuspendLayout();
            // 
            // pb_tube_light
            // 
            this.pb_tube_light.BackgroundImage = global::IoT_Switch_Board.Properties.Resources.img_sw_OFF;
            this.pb_tube_light.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pb_tube_light.Location = new System.Drawing.Point(23, 28);
            this.pb_tube_light.Name = "pb_tube_light";
            this.pb_tube_light.Size = new System.Drawing.Size(76, 110);
            this.pb_tube_light.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_tube_light.TabIndex = 0;
            this.pb_tube_light.TabStop = false;
            this.pb_tube_light.Click += new System.EventHandler(this.pb_tube_light_Click);
            // 
            // nUD_fan_speed
            // 
            this.nUD_fan_speed.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.nUD_fan_speed.Location = new System.Drawing.Point(699, 52);
            this.nUD_fan_speed.Name = "nUD_fan_speed";
            this.nUD_fan_speed.Size = new System.Drawing.Size(69, 39);
            this.nUD_fan_speed.TabIndex = 1;
            this.nUD_fan_speed.ValueChanged += new System.EventHandler(this.nUD_fan_speed_ValueChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(31, 141);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(69, 15);
            this.label1.TabIndex = 2;
            this.label1.Text = "TUBE LIGHT";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(141, 141);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(39, 15);
            this.label2.TabIndex = 2;
            this.label2.Text = "LIGHT";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(216, 141);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(77, 15);
            this.label3.TabIndex = 2;
            this.label3.Text = "NIGHT LAMP";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(338, 141);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(26, 15);
            this.label4.TabIndex = 2;
            this.label4.Text = "T.V.";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(434, 141);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(29, 15);
            this.label5.TabIndex = 2;
            this.label5.Text = "A.C.";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(536, 141);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(36, 15);
            this.label6.TabIndex = 2;
            this.label6.Text = "PLUG";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(632, 141);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(29, 15);
            this.label7.TabIndex = 2;
            this.label7.Text = "FAN";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(699, 94);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(65, 15);
            this.label8.TabIndex = 2;
            this.label8.Text = "FAN SPEED";
            // 
            // pb_light
            // 
            this.pb_light.BackgroundImage = global::IoT_Switch_Board.Properties.Resources.img_sw_OFF;
            this.pb_light.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pb_light.Location = new System.Drawing.Point(120, 28);
            this.pb_light.Name = "pb_light";
            this.pb_light.Size = new System.Drawing.Size(76, 110);
            this.pb_light.TabIndex = 3;
            this.pb_light.TabStop = false;
            this.pb_light.Click += new System.EventHandler(this.pb_light_Click);
            // 
            // pb_night_lamp
            // 
            this.pb_night_lamp.BackgroundImage = global::IoT_Switch_Board.Properties.Resources.img_sw_OFF;
            this.pb_night_lamp.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pb_night_lamp.Location = new System.Drawing.Point(213, 28);
            this.pb_night_lamp.Name = "pb_night_lamp";
            this.pb_night_lamp.Size = new System.Drawing.Size(76, 110);
            this.pb_night_lamp.TabIndex = 3;
            this.pb_night_lamp.TabStop = false;
            this.pb_night_lamp.Click += new System.EventHandler(this.pb_night_lamp_Click);
            // 
            // pb_tv
            // 
            this.pb_tv.BackgroundImage = global::IoT_Switch_Board.Properties.Resources.img_sw_OFF;
            this.pb_tv.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pb_tv.Location = new System.Drawing.Point(308, 28);
            this.pb_tv.Name = "pb_tv";
            this.pb_tv.Size = new System.Drawing.Size(76, 110);
            this.pb_tv.TabIndex = 3;
            this.pb_tv.TabStop = false;
            this.pb_tv.Click += new System.EventHandler(this.pb_tv_Click_1);
            // 
            // pb_ac
            // 
            this.pb_ac.BackgroundImage = global::IoT_Switch_Board.Properties.Resources.img_sw_OFF;
            this.pb_ac.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pb_ac.Location = new System.Drawing.Point(408, 28);
            this.pb_ac.Name = "pb_ac";
            this.pb_ac.Size = new System.Drawing.Size(76, 110);
            this.pb_ac.TabIndex = 3;
            this.pb_ac.TabStop = false;
            this.pb_ac.Click += new System.EventHandler(this.pb_ac_Click);
            // 
            // pb_plug
            // 
            this.pb_plug.BackgroundImage = global::IoT_Switch_Board.Properties.Resources.img_sw_OFF;
            this.pb_plug.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pb_plug.Location = new System.Drawing.Point(512, 28);
            this.pb_plug.Name = "pb_plug";
            this.pb_plug.Size = new System.Drawing.Size(76, 110);
            this.pb_plug.TabIndex = 3;
            this.pb_plug.TabStop = false;
            this.pb_plug.Click += new System.EventHandler(this.pb_plug_Click);
            // 
            // pb_fan
            // 
            this.pb_fan.BackgroundImage = global::IoT_Switch_Board.Properties.Resources.img_sw_OFF;
            this.pb_fan.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pb_fan.Location = new System.Drawing.Point(603, 28);
            this.pb_fan.Name = "pb_fan";
            this.pb_fan.Size = new System.Drawing.Size(76, 110);
            this.pb_fan.TabIndex = 3;
            this.pb_fan.TabStop = false;
            this.pb_fan.Click += new System.EventHandler(this.pb_fan_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.BackgroundImage = global::IoT_Switch_Board.Properties.Resources.img_base;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(789, 167);
            this.Controls.Add(this.pb_fan);
            this.Controls.Add(this.pb_plug);
            this.Controls.Add(this.pb_ac);
            this.Controls.Add(this.pb_tv);
            this.Controls.Add(this.pb_night_lamp);
            this.Controls.Add(this.pb_light);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.nUD_fan_speed);
            this.Controls.Add(this.pb_tube_light);
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "IoT Soft Switchboard";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pb_tube_light)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nUD_fan_speed)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_light)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_night_lamp)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_tv)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_ac)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_plug)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_fan)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private PictureBox pb_tube_light;
        private NumericUpDown nUD_fan_speed;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private PictureBox pb_light;
        private PictureBox pb_night_lamp;
        private PictureBox pb_tv;
        private PictureBox pb_ac;
        private PictureBox pb_plug;
        private PictureBox pb_fan;
    }
}