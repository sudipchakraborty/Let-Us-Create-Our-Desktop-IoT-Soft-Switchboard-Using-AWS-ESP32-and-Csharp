using Tools;

namespace IoT_Switch_Board
{
    public partial class Form1 : Form
    {
        AWS_MQTT_Client device=new AWS_MQTT_Client();
        Image img_sw_on, img_sw_off;

        public Form1()
        {
            InitializeComponent();
            img_sw_on=Image.FromFile("img_sw_ON.png");
            img_sw_off=Image.FromFile("img_sw_OFF.png");
           
            pb_tube_light.BackgroundImageLayout=ImageLayout.Stretch;
            pb_light.BackgroundImageLayout=ImageLayout.Stretch;
            pb_night_lamp.BackgroundImageLayout=ImageLayout.Stretch;
            pb_tv.BackgroundImageLayout=ImageLayout.Stretch;
            pb_ac.BackgroundImageLayout=ImageLayout.Stretch;
            pb_plug.BackgroundImageLayout=ImageLayout.Stretch;
            pb_fan.BackgroundImageLayout=ImageLayout.Stretch;

            nUD_fan_speed.Maximum= 100;
            nUD_fan_speed.Minimum=0;
            nUD_fan_speed.Increment=5;
           


            device.connect();
        }

        private void pb_tube_light_Click(object sender, EventArgs e)
        {
            if (pb_tube_light.Image==img_sw_on)
            {
                pb_tube_light.Image=img_sw_off;
                device.process_command("tube light off");
            }
            else
            {
                pb_tube_light.Image=img_sw_on;
                device.process_command("tube light on");
            }
                 
        }

        private void pb_light_Click(object sender, EventArgs e)
        {
            if (pb_light.Image==img_sw_on)
            {
                pb_light.Image=img_sw_off;
                device.process_command("light off");
            }
            else
            {
                pb_light.Image=img_sw_on;
                device.process_command("light on");
            }
        }

        private void pb_night_lamp_Click(object sender, EventArgs e)
        {
            if (pb_night_lamp.Image==img_sw_on)
            {
                pb_night_lamp.Image=img_sw_off;
                device.process_command("night lamp off");
            }
            else
            { 
                pb_night_lamp.Image=img_sw_on;
                device.process_command("night lamp on");
            }
        }

        private void pb_tv_Click_1(object sender, EventArgs e)
        {
            if (pb_tv.Image==img_sw_on)
            {
                pb_tv.Image=img_sw_off;
                // device.process_command("tube light off");
            }
            else
            {
                pb_tv.Image=img_sw_on;
              //  device.process_command("tube light off");
            }
                
        }

        private void pb_ac_Click(object sender, EventArgs e)
        {
            if (pb_ac.Image==img_sw_on)
            {
                pb_ac.Image=img_sw_off;
              // device.process_command("tube light off");
            }
            else
            {
                pb_ac.Image=img_sw_on;
               // device.process_command("tube light off");
            }
        }

        private void pb_plug_Click(object sender, EventArgs e)
        {
            if (pb_plug.Image==img_sw_on)
            {
                pb_plug.Image=img_sw_off;
             //   device.process_command("tube light off");
            }
            else
            {
                pb_plug.Image=img_sw_on;
               // device.process_command("tube light off");
            }
        }

        private void pb_fan_Click(object sender, EventArgs e)
        {
            if (pb_fan.Image==img_sw_on)
            {
                pb_fan.Image=img_sw_off;
                device.process_command("fan off");
            }
            else
            {
                pb_fan.Image=img_sw_on;
                device.process_command("fan on");
            }
        }

        private void nUD_fan_speed_ValueChanged(object sender, EventArgs e)
        {
            string val = nUD_fan_speed.Value.ToString();
            device.process_command("fan speed "+ val);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.BackgroundImage=Image.FromFile("img_base.jpg");
            pb_tube_light.Image = img_sw_on;
        }
    }
}